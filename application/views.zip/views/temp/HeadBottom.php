<!--begin::Global Theme Styles(used by all pages) -->                    
<link href="<?php echo base_url(); ?>assets/css/demo2/style.bundle.css" rel="stylesheet" type="text/css" />
        <!--end::Global Theme Styles -->

        <!--begin::Layout Skins(used by all pages) -->
                <!--end::Layout Skins -->
        <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/media/logos/gha-sm.png" />
    </head>
    <!-- end::Head -->

    <!-- begin::Body -->
    <body  class="kt-page--loading-enabled kt-page--loading kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header--minimize-topbar kt-header-mobile--fixed kt-subheader--enabled kt-subheader--transparent kt-page--loading"  >

    <!-- begin::Page loader -->
	
<!-- end::Page Loader -->        