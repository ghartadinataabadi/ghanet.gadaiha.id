<?php
require_once APPPATH.'controllers/api/ApiController.php';

class Kpi extends ApiController
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('CronjobModel', 'cronjob');
	}

	public function index()
	{
        $data['description'] = 'create new daily outstanding successfully at '.date('Y-m-d H:i:s');

        if($this->cronjob->db->insert('cronjob', $data)){
            echo json_encode(array(
                'data'	=> $data,
                'message'	=> 'Successfully Get Data Users'
            ));
        }
	}

}
