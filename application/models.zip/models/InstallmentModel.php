<?php
require_once 'Master.php';
class InstallmentModel extends Master
{
	public $table = 'installlment_items';
	public $primary_key = 'id';

}