<?php
require_once 'Master.php';
class JournalEntries extends Master
{
	public $table = 'journal_entries';
	public $primary_key = 'id';

}