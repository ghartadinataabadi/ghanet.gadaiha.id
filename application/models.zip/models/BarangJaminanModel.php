<?php
require_once 'Master.php';
class BarangJaminanModel extends Master
{
	public $table = 'units_regularpawns_verified';

	public $level = true;

	public $primary_key = 'id';

}
