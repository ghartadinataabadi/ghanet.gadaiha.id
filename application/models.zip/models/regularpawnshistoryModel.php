<?php
require_once 'Master.php';
class regularpawnshistoryModel extends Master
{
	public $table = 'units_regularpawns_history';

	public $primary_key = 'id';

}
