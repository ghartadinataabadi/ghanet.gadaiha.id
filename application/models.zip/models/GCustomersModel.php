<?php
require_once 'Master.php';
class GCustomersModel extends Master
{
	public $table = 'customers';
	public $primary_key = 'id';

}