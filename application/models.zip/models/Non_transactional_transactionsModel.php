<?php
require_once 'Master.php';
class Non_transactional_transactionsModel extends Master
{
	public $table = 'non_transactional_transactions';
	public $primary_key = 'id';

}