<?php
require_once 'Master.php';
class KencanaProductModel extends Master
{
	public $table = 'kencana_products';
	public $primary_key = 'id';

}


