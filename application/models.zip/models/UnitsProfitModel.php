<?php 
require_once 'Master.php';
class UnitsProfitModel extends Master
{
    public $table = 'units_profit';
    public $primary_key = 'id';


}
?>