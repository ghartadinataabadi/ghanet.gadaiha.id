<?php
require_once 'Master.php';
class DailyCashes extends Master
{
	public $table = 'daily_cashes';
	public $primary_key = 'id';

}