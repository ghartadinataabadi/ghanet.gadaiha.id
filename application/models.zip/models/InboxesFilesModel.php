<?php
require_once 'Master.php';
class InboxesFilesModel extends Master
{
	/**
	 * @var string
	 */

	public $table = 'inboxes_files';

	/**
	 * @var string
	 */

	public $primary_key = 'id';
}
