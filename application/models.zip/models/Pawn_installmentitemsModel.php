<?php
require_once 'Master.php';
class Pawn_installmentitemsModel extends Master
{
	public $table = 'installment_items';
	public $primary_key = 'id';
}