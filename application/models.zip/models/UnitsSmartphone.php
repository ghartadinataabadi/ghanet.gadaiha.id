<?php
require_once 'Master.php';
class UnitsSmartphone extends Master
{
	public $table = 'units_smartphone';
	public $primary_key = 'id';

}
