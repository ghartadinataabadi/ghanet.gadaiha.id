<?php
require_once 'Master.php';
class KencanaStockModel extends Master
{
	public $table = 'kencana_stocks';
	public $primary_key = 'id';

}


