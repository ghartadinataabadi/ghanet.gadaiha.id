<?php
require_once 'Master.php';
class BookCashMoneyModel extends Master
{
	public $table = 'units_cash_book_money';

	public $primary_key = 'id';

}
