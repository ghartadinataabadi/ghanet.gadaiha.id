<?php
require_once 'Master.php';
class LmTransactionsGramsModel extends Master
{
	public $table = 'lm_transactions_grams';
	public $primary_key = 'id';
}
