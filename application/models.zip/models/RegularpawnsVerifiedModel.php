<?php
require_once 'Master.php';
class RegularpawnsVerifiedModel extends Master
{
	public $table = 'units_regularpawns_verified';
	public $primary_key = 'id';

}


