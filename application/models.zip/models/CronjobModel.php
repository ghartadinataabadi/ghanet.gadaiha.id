<?php
require_once 'Master.php';
class CronjobModel extends Master
{
	
	public $table = 'cronjob';
	public $primary_key = 'id';

}


