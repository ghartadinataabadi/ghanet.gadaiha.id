<?php
require_once 'Master.php';
class Pawn_transactionsModel extends Master
{
	public $table = 'pawn_transactions';
	public $primary_key = 'id';
}