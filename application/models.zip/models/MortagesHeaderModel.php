<?php
require_once 'Master.php';
class MortagesHeaderModel extends Master
{
	public $table = 'units_mortages_header';
	public $primary_key = 'id';

}


