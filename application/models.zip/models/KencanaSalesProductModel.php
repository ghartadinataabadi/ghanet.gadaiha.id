<?php
require_once 'Master.php';
class KencanaSalesProductModel extends Master
{
	public $table = 'kencana_sales_products';
	public $primary_key = 'id';

}


