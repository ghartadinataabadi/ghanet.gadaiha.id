<?php
require_once 'Master.php';
class LevelsModel extends Master
{
	/**
	 * @var string
	 */

	public $table = 'levels';

	/**
	 * @var string
	 */

	public $primary_key = 'id';
}
