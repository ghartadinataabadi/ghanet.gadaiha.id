<?php
require_once 'Master.php';
class UnitsRateModel extends Master
{
	public $table = 'units_rate';
	public $primary_key = 'id';

	
}


