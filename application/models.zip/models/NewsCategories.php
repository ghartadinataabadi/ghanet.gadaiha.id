<?php
require_once 'Master.php';
class NewsCategories extends Master
{
	public $table = 'news_categories';
	public $primary_key = 'id';

}


