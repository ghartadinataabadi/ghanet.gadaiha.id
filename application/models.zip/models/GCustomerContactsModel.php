<?php
require_once 'Master.php';
class GCustomerContactsModel extends Master
{
	public $table = 'customer_contacts';
	public $primary_key = 'id';

}