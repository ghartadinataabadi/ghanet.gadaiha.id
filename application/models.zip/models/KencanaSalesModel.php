<?php
require_once 'Master.php';
class KencanaSalesModel extends Master
{
	public $table = 'kencana_sales';
	public $primary_key = 'id';

}


