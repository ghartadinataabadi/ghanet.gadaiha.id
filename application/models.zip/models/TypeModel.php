<?php
require_once 'Master.php';
class TypeModel extends Master
{
	public $table = 'type';
	public $primary_key = 'id';

}
