<?php
require_once 'Master.php';
class SeriesModel extends Master
{
	public $table = 'series';
	public $primary_key = 'id';

}
