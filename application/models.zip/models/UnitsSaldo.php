<?php
require_once 'Master.php';
class UnitsSaldo extends Master
{
	/**
	 * @var string
	 */

	public $table = 'units_saldo';

	/**
	 * @var string
	 */

	public $primary_key = 'id';

	public $hirarki = true;
}
